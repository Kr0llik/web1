from flask import Flask, \
    render_template, url_for, request
from PIL import Image
import os

app = Flask(__name__)


@app.route('/<title>')
@app.route('/index/<title>')
def index(title):
    return render_template('base.html', title=title)


@app.route('/training/<prof>')
def p(prof):
    return render_template('training.html', title=prof.lower())


@app.route('/form_sample', methods=['POST', 'GET'])
def form_sample():
    if request.method == 'GET':
        return render_template('upload_file.html',
                               title="title",
                               flag=os.path.isfile(f"{os.getcwd()}/static/img/st.png"))
    elif request.method == 'POST':
        f = request.files['file']
        image = Image.open(f)
        if os.path.isfile(f"{os.getcwd()}/static/img/st.png"):
            os.remove(f"{os.getcwd()}/static/img/st.png")
        image = image.resize((700, 700), Image.LANCZOS)
        image.save(f"{os.getcwd()}/static/img/st.png")

        return "Форма отправлена"


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
