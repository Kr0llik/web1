from flask import Flask, render_template

app = Flask(__name__)


@app.route('/<title>')
@app.route('/index/<title>')
def index(title):
    return render_template('base.html', title=title)


@app.route('/choice/<planet_name>')
def p(planet_name):
    if planet_name.lower() not in ['меркурий', 'марс', 'венера',
                                 'земля', 'юпитер', 'нептун',
                                 'сатурн', 'уран']:
        return render_template('')
    return render_template('planet.html', title=planet_name.lower())


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
