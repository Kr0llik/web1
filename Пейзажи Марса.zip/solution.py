from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/promotion_image')
def promotion():
    return render_template('landscapes_of_mars.html', title="Пейзажи Марса")


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
